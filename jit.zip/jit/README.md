# 🎓 G H RAISONI COLLEGE OF ENGINEERING AND MANAGEMENT, PUNE
### (An Autonomous Institute Affiliated to Savitribai Phule Pune University)
### Department of Data Science | Academic Year 2026–2027

---

# 🎟️ DBMS TAE-1: EVENT MANAGEMENT DATABASE SYSTEM

[![SQL Engine](https://img.shields.io/badge/RDBMS-MS%20SQL%20Server%20%7C%20PostgreSQL%20%7C%20MySQL-0078D4?style=for-the-badge&logo=microsoftsqlserver&logoColor=white)](https://www.microsoft.com/en-us/sql-server)
[![Normalization](https://img.shields.io/badge/Normalization-1NF%20%E2%86%92%202NF%20%E2%86%92%203NF%20%E2%86%92%20BCNF-success?style=for-the-badge)](https://en.wikipedia.org/wiki/Database_normalization)
[![Course](https://img.shields.io/badge/Course-Database%20Management%20Systems-orange?style=for-the-badge)](https://en.wikipedia.org/wiki/Database)

---

## 👨‍🎓 1. Student & Submission Details

| Parameter | Details |
|:---|:---|
| **Student Name** | **Prasenjit Bakkawar** |
| **Registration Number (PRN)** | **24ACDS1121069** |
| **Section** | **A3** |
| **Branch / Class** | **TY - Data Science (TY - DS)** |
| **Department** | **Department of Data Science** |
| **Institute** | **G H Raisoni College of Engineering and Management, Pune** |
| **Evaluation Milestone** | **TAE-1 (Teacher Assessment Examination 1)** |
| **Subject** | **Database Management Systems (DBMS)** |
| **Faculty Name** | **Mr. Chinmay Mukim Sir** |

---

## 📌 2. Database System Title
**Event Management Relational Database System**

---

## 🎯 3. Problem Statement & System Requirements

### 3.1 Introduction
The **Event Management Database System** is a relational database application designed to efficiently manage the planning, organization, and execution of various events (such as Hackathons, AI Workshops, Technical Symposiums, and Cultural Fests). It provides a centralized platform for storing and managing information related to:
* **Events** & their schedules
* **Participants** (Students, Delegates)
* **Organizers** (Faculty coordinators, Student committee leads)
* **Venues** (Auditoriums, Labs, Seminar Halls)
* **Registrations** & seat allocations
* **Payments** (Online, Cash, UPI transactions)
* **Certificates** (Participation, Merit, Winner awards)

### 3.2 Problem Statement
Traditional event management methods often rely on fragmented spreadsheets, Google Forms, or manual paper records. These lead to:
* **Data Redundancy & Inconsistencies:** Duplicate participant entries across multiple events.
* **Scheduling Conflicts:** Double-booking the same auditorium or lab across overlapping events.
* **Payment Reconciliation Gaps:** Missing transaction references and unverified registrations.
* **Certificate Issuance Delays:** Manual errors in participant names, college details, and award categories.

The relational database ensures entity integrity, referential constraints, eliminates anomalies through BCNF normalization, and provides instant query execution for reporting.

---

### 3.3 Business Domain & Constraints

#### Enterprise Entities:
1. **Participants** (`Participant_ID`, `Participant_Name`, `Email`, `Phone`, `College`, `Department`)
2. **Events** (`Event_ID`, `Event_Name`, `Event_Date`, `Category`, `Registration_Fee`, `Organizer_ID`, `Venue_ID`)
3. **Organizers** (`Organizer_ID`, `Organizer_Name`, `Email`, `Phone`)
4. **Venues** (`Venue_ID`, `Venue_Name`, `Location`, `Capacity`)
5. **Registrations** (`Registration_ID`, `Participant_ID`, `Event_ID`, `Registration_Date`, `Status`)
6. **Payments** (`Payment_ID`, `Registration_ID`, `Amount`, `Payment_Mode`, `Payment_Date`, `Payment_Status`)
7. **Certificates** (`Certificate_ID`, `Participant_ID`, `Event_ID`, `Certificate_Type`, `Issue_Date`)

#### Integrity Constraints:
* **Entity Integrity:** Every participant, event, organizer, venue, registration, payment, and certificate has a distinct, non-null Primary Key.
* **Referential Integrity:** `Registration.Participant_ID` and `Registration.Event_ID` reference existing records with foreign keys (`ON DELETE CASCADE` or `RESTRICT`).
* **Multiplicity:**
  - One participant can register for multiple events ($1:N$).
  - One event can have multiple registered participants ($1:N$).
  - Each registration uniquely binds one participant to one event.
  - Each registration has a corresponding payment record ($1:1$).
  - A certificate is issued only to validly registered participants ($1:N$).

---

### 3.4 Operational Transactions (OLTP Queries)
* **$T_1$:** Add new events and assign dates, fees, and venues.
* **$T_2$:** Update event details and scheduling parameters.
* **$T_3$:** Register participants and generate unique `Registration_ID`.
* **$T_4$:** Assign organizers to coordinate specific events.
* **$T_5$:** Process and verify registration payment transactions (`Payment_Status = 'Paid'`).
* **$T_6$:** Record attendance and issue verification certificates.

---

## 📚 4. Literature & System Survey

| # | Reference / Technical Literature | Key Database Architecture Takeaways |
|---|---|---|
| **1** | **Title:** *Event Management System Using Web Technology* | Focuses on multi-user concurrency, role-based access for organizers/attendees, and web database integration. |
| **2** | **Title:** *Database System Concepts* by Silberschatz, Korth, Sudarshan | Comprehensive principles of relational data models, transaction atomicity (ACID), and query optimization. |
| **3** | **Title:** *Fundamentals of Database Systems (7th Edition)* by Elmasri & Navathe | Standards for Entity-Relationship (ER/EER) modeling, functional dependency analysis, and formal normalization proofs (1NF to BCNF). |

---

## 📐 5. Conceptual Schema (ER Diagram)

### 5.1 Mermaid ER Diagram

```mermaid
erDiagram
    ORGANIZERS ||--o{ EVENTS : organizes
    VENUES ||--o{ EVENTS : hosts
    EVENTS ||--|{ REGISTRATIONS : has
    PARTICIPANTS ||--|{ REGISTRATIONS : registers_for
    REGISTRATIONS ||--|| PAYMENTS : paid_by
    PARTICIPANTS ||--o{ CERTIFICATES : receives
    EVENTS ||--o{ CERTIFICATES : awards

    ORGANIZERS {
        int Organizer_ID PK
        string Organizer_Name
        string Email UK
        string Phone
    }

    VENUES {
        int Venue_ID PK
        string Venue_Name
        string Location
        int Capacity
    }

    EVENTS {
        int Event_ID PK
        int Organizer_ID FK
        int Venue_ID FK
        string Event_Name
        date Event_Date
        string Category
        decimal Registration_Fee
    }

    PARTICIPANTS {
        int Participant_ID PK
        string Participant_Name
        string Email UK
        string Phone
        string College
        string Department
    }

    REGISTRATIONS {
        int Registration_ID PK
        int Participant_ID FK
        int Event_ID FK
        date Registration_Date
        string Status
    }

    PAYMENTS {
        int Payment_ID PK
        int Registration_ID FK, UK
        decimal Amount
        string Payment_Mode
        date Payment_Date
        string Payment_Status
    }

    CERTIFICATES {
        int Certificate_ID PK
        int Participant_ID FK
        int Event_ID FK
        string Certificate_Type
        date Issue_Date
    }
```

---

## 🔄 6. Step-by-Step Normalisation Proof (UNF $\rightarrow$ 1NF $\rightarrow$ 2NF $\rightarrow$ 3NF $\rightarrow$ BCNF)

### 6.1 Unnormalized Form (UNF)
Initially, raw unnormalized event logs contain multi-valued repeating groups and flattened attributes:

$$\text{RAW\_EVENT\_RECORD}(\underline{\text{RegistrationID}}, \text{ParticipantName}, \text{Phone}, \text{College}, \text{Dept}, \text{EventName}, \text{EventDate}, \text{Organizer}, \text{Venue}, \text{PaymentStatus}, \text{Certificate})$$

| RegistrationID | ParticipantName | Phone | EventName | Organizer | Venue | Payment | Certificate |
|---|---|---|---|---|---|---|---|
| **R001** | Aarav Sharma | 9876543210 | Hackathon | Rahul Mehta | Auditorium | Paid | Yes |
| **R001** | Aarav Sharma | 9876543210 | AI Workshop | Rahul Mehta | Lab 1 | Paid | No |

**Problems in UNF:**
1. **Repeated Participant Information:** Duplicate phone, name, and department entries.
2. **Duplicate Event Details:** Redundant organizer and venue records.
3. **Data Redundancy & Update Anomalies:** Changing an organizer's contact details requires updating every past registration row.

---

### 6.2 First Normal Form (1NF)
* **Rule:** Remove repeating groups, ensure atomic (indivisible) attribute values, and define a valid Primary Key.
* **Result:** Atomized table with single values per cell.

$$\text{REGISTRATIONS}(\underline{\text{Registration\_ID}}, \text{Participant\_ID}^*, \text{Event\_ID}^*, \text{Registration\_Date}, \text{Status})$$

| Registration_ID (PK) | Participant_ID | Event_ID | Registration_Date | Status |
|---|---|---|---|---|
| **R001** | P001 | E001 | 2026-10-09 | Registered |
| **R002** | P001 | E002 | 2026-10-15 | Registered |

---

### 6.3 Second Normal Form (2NF)
* **Rule:** Must be in 1NF and have **NO Partial Functional Dependencies** (every non-key attribute must depend on the whole primary key).
* **Decomposition into 2NF Tables:**

1. **`PARTICIPANTS` Table:**
   $$\underline{\text{Participant\_ID}}, \text{Participant\_Name}, \text{Email}, \text{Phone}, \text{College}, \text{Department}$$
2. **`EVENTS` Table:**
   $$\underline{\text{Event\_ID}}, \text{Event\_Name}, \text{Event\_Date}, \text{Category}, \text{Venue\_ID}^*, \text{Organizer\_ID}^*$$
3. **`REGISTRATIONS` Table:**
   $$\underline{\text{Registration\_ID}}, \text{Participant\_ID}^*, \text{Event\_ID}^*, \text{Registration\_Date}, \text{Status}$$

*Outcome:* Every non-key attribute is now fully functionally dependent on its respective primary key.

---

### 6.4 Third Normal Form (3NF)
* **Rule:** Must be in 2NF and have **NO Transitive Dependencies** ($X \rightarrow Y \rightarrow Z$ where non-key determines non-key).
* **Decomposition into 3NF Tables:**

1. **`ORGANIZERS` Table:**
   $$\underline{\text{Organizer\_ID}}, \text{Organizer\_Name}, \text{Email}, \text{Phone}$$
2. **`VENUES` Table:**
   $$\underline{\text{Venue\_ID}}, \text{Venue\_Name}, \text{Location}, \text{Capacity}$$
3. **`PAYMENTS` Table:**
   $$\underline{\text{Payment\_ID}}, \text{Registration\_ID}^*, \text{Amount}, \text{Payment\_Mode}, \text{Payment\_Status}, \text{Payment\_Date}$$
4. **`CERTIFICATES` Table:**
   $$\underline{\text{Certificate\_ID}}, \text{Participant\_ID}^*, \text{Event\_ID}^*, \text{Certificate\_Type}, \text{Issue\_Date}$$

*Outcome:* Non-key attributes depend exclusively on their table's primary key and nothing else.

---

### 6.5 Boyce–Codd Normal Form (BCNF)
The schema satisfies BCNF because:
1. Every table has a single, well-defined candidate key.
2. For every non-trivial functional dependency $X \rightarrow Y$, $X$ is a superkey.
3. No non-key attribute determines any other attribute.
4. All functional dependencies have candidate keys on the left-hand side.

---

## 💻 7. Target RDBMS Software

* **Target Database Engine:** **Microsoft SQL Server / PostgreSQL / MySQL**
* **Engineering Justification:**
  - Robust enforcement of **Entity Integrity** (Primary Keys) and **Referential Integrity** (Foreign Keys with cascading actions).
  - Fast transactional retrieval via indexed lookups on `Participant_ID`, `Event_ID`, and `Registration_ID`.
  - ACID transaction support ensuring payments, registrations, and certificate grants occur atomically.

---

## 📁 Repository Directory Structure

```
OmniEvent-Database-System/
├── README.md                  # Complete TAE-1 DBMS Submission Document
├── docs/
│   └── ER_DIAGRAM.md          # Conceptual ER Diagram & Schema Specifications
├── sql/
│   ├── schema.sql             # BCNF-Normalized DDL Table Definitions
│   ├── sample_data.sql        # Seed Records for Academic & Hackathon Events
│   └── sample_queries.sql     # Operational SQL Queries (T1 through T6)
└── scripts/
    └── db_runner.py           # Automated Test & Demonstration Runner
```
