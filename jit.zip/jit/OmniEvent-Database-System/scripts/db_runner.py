"""
G H RAISONI COLLEGE OF ENGINEERING AND MANAGEMENT, PUNE
Department of Data Science | DBMS TAE-1
Title: EVENT MANAGEMENT DATABASE SYSTEM
Student: Prasenjit Bakkawar (PRN: 24ACDS1121069) | Section: A3 | TY-DS
Faculty: Mr. Chinmay Mukim Sir
"""

import sys
import sqlite3

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

def run_tae1_demo():
    conn = sqlite3.connect(":memory:")
    cursor = conn.cursor()

    print("========================================================================")
    print(" G H RAISONI COLLEGE OF ENGINEERING AND MANAGEMENT, PUNE")
    print(" Department of Data Science | DBMS TAE-1 Submission")
    print(" Title: EVENT MANAGEMENT DATABASE SYSTEM")
    print(" Student: Prasenjit Bakkawar (PRN: 24ACDS1121069) | Section: A3 | TY-DS")
    print(" Faculty: Mr. Chinmay Mukim Sir")
    print("========================================================================\n")

    schema_sql = """
    CREATE TABLE ORGANIZERS (
        Organizer_ID INT PRIMARY KEY,
        Organizer_Name TEXT NOT NULL,
        Email TEXT UNIQUE NOT NULL,
        Phone TEXT NOT NULL
    );

    CREATE TABLE VENUES (
        Venue_ID INT PRIMARY KEY,
        Venue_Name TEXT NOT NULL,
        Location TEXT NOT NULL,
        Capacity INT NOT NULL CHECK (Capacity > 0)
    );

    CREATE TABLE EVENTS (
        Event_ID INT PRIMARY KEY,
        Event_Name TEXT NOT NULL,
        Event_Date DATE NOT NULL,
        Category TEXT NOT NULL,
        Registration_Fee DECIMAL(10, 2) NOT NULL CHECK (Registration_Fee >= 0.00),
        Venue_ID INT NOT NULL,
        Organizer_ID INT NOT NULL,
        FOREIGN KEY (Venue_ID) REFERENCES VENUES(Venue_ID),
        FOREIGN KEY (Organizer_ID) REFERENCES ORGANIZERS(Organizer_ID)
    );

    CREATE TABLE PARTICIPANTS (
        Participant_ID INT PRIMARY KEY,
        Participant_Name TEXT NOT NULL,
        Email TEXT UNIQUE NOT NULL,
        Phone TEXT NOT NULL,
        College TEXT NOT NULL,
        Department TEXT NOT NULL
    );

    CREATE TABLE REGISTRATIONS (
        Registration_ID INT PRIMARY KEY,
        Participant_ID INT NOT NULL,
        Event_ID INT NOT NULL,
        Registration_Date DATE NOT NULL,
        Status TEXT DEFAULT 'Registered' CHECK (Status IN ('Registered', 'Attended', 'Cancelled')),
        FOREIGN KEY (Participant_ID) REFERENCES PARTICIPANTS(Participant_ID),
        FOREIGN KEY (Event_ID) REFERENCES EVENTS(Event_ID),
        UNIQUE (Participant_ID, Event_ID)
    );

    CREATE TABLE PAYMENTS (
        Payment_ID INT PRIMARY KEY,
        Registration_ID INT UNIQUE NOT NULL,
        Amount DECIMAL(10, 2) NOT NULL CHECK (Amount >= 0.00),
        Payment_Mode TEXT NOT NULL CHECK (Payment_Mode IN ('UPI', 'Credit Card', 'Debit Card', 'Net Banking', 'Cash')),
        Payment_Date DATE NOT NULL,
        Payment_Status TEXT DEFAULT 'Paid' CHECK (Payment_Status IN ('Paid', 'Pending', 'Failed', 'Refunded')),
        FOREIGN KEY (Registration_ID) REFERENCES REGISTRATIONS(Registration_ID)
    );

    CREATE TABLE CERTIFICATES (
        Certificate_ID INT PRIMARY KEY,
        Participant_ID INT NOT NULL,
        Event_ID INT NOT NULL,
        Certificate_Type TEXT NOT NULL CHECK (Certificate_Type IN ('Participation', 'Merit', 'Winner', 'Runner-up', 'Organizer')),
        Issue_Date DATE NOT NULL,
        FOREIGN KEY (Participant_ID) REFERENCES PARTICIPANTS(Participant_ID),
        FOREIGN KEY (Event_ID) REFERENCES EVENTS(Event_ID)
    );
    """
    cursor.executescript(schema_sql)
    print("[SUCCESS] 1. All 7 BCNF Normalized Schema Tables Created.")

    seed_sql = """
    INSERT INTO ORGANIZERS VALUES
    (101, 'Prof. Rahul Mehta', 'rahul.mehta@ghrcem.edu.in', '9876543210'),
    (102, 'Dr. Sneha Kulkarni', 'sneha.kulkarni@ghrcem.edu.in', '9822012345'),
    (103, 'Prof. Amit Verma', 'amit.verma@ghrcem.edu.in', '9765432109');

    INSERT INTO VENUES VALUES
    (201, 'Central Auditorium', 'Main Building, Ground Floor', 500),
    (202, 'Data Science Lab 1', 'Department of Data Science, 3rd Floor', 80),
    (203, 'Seminar Hall A', 'Mechanical Block, 2nd Floor', 150);

    INSERT INTO EVENTS VALUES
    (301, 'National Hackathon 2026', '2026-10-15', 'Hackathon', 250.00, 201, 101),
    (302, 'Hands-on AI & ML Workshop', '2026-10-20', 'Workshop', 150.00, 202, 102),
    (303, 'Web3 & Cloud Symposium', '2026-11-05', 'Technical', 100.00, 203, 103);

    INSERT INTO PARTICIPANTS VALUES
    (401, 'Aarav Sharma', 'aarav.sharma@gmail.com', '9876543210', 'GHRCEM Pune', 'Data Science'),
    (402, 'Priya Patil', 'priya.patil@gmail.com', '9823456781', 'GHRCEM Pune', 'Computer Engineering'),
    (403, 'Rohan Deshmukh', 'rohan.d@gmail.com', '9890123456', 'COEP Pune', 'Information Technology'),
    (404, 'Ananya Joshi', 'ananya.j@gmail.com', '9765123489', 'PICT Pune', 'Data Science');

    INSERT INTO REGISTRATIONS VALUES
    (501, 401, 301, '2026-10-01', 'Attended'),
    (502, 401, 302, '2026-10-02', 'Registered'),
    (503, 402, 301, '2026-10-03', 'Attended'),
    (504, 403, 302, '2026-10-04', 'Attended'),
    (505, 404, 303, '2026-10-05', 'Registered');

    INSERT INTO PAYMENTS VALUES
    (601, 501, 250.00, 'UPI', '2026-10-01', 'Paid'),
    (602, 502, 150.00, 'UPI', '2026-10-02', 'Paid'),
    (603, 503, 250.00, 'Credit Card', '2026-10-03', 'Paid'),
    (604, 504, 150.00, 'Net Banking', '2026-10-04', 'Paid'),
    (605, 505, 100.00, 'UPI', '2026-10-05', 'Paid');

    INSERT INTO CERTIFICATES VALUES
    (701, 401, 301, 'Winner', '2026-10-16'),
    (702, 402, 301, 'Runner-up', '2026-10-16'),
    (703, 403, 302, 'Participation', '2026-10-21');
    """
    cursor.executescript(seed_sql)
    print("[SUCCESS] 2. Seed Records Inserted for all Entities.\n")

    print("--- 📊 Operational Query T4: Event-wise Registration & Fee Summary ---")
    q4 = """
    SELECT 
        e.Event_Name,
        e.Event_Date,
        v.Venue_Name,
        o.Organizer_Name,
        COUNT(r.Registration_ID) AS Registrations,
        COALESCE(SUM(p.Amount), 0.00) AS TotalFee
    FROM EVENTS e
    JOIN VENUES v ON e.Venue_ID = v.Venue_ID
    JOIN ORGANIZERS o ON e.Organizer_ID = o.Organizer_ID
    LEFT JOIN REGISTRATIONS r ON e.Event_ID = r.Event_ID
    LEFT JOIN PAYMENTS p ON r.Registration_ID = p.Registration_ID AND p.Payment_Status = 'Paid'
    GROUP BY e.Event_ID, e.Event_Name, e.Event_Date, v.Venue_Name, o.Organizer_Name;
    """
    cursor.execute(q4)
    rows = cursor.fetchall()
    print(f"{'Event Name':<28} | {'Date':<10} | {'Venue':<20} | {'Organizer':<20} | {'Regs':<4} | {'Fee Collected':<12}")
    print("-" * 105)
    for r in rows:
        print(f"{r[0]:<28} | {r[1]:<10} | {r[2]:<20} | {r[3]:<20} | {r[4]:<4} | ${r[5]:<11.2f}")

    print("\n--- 💳 Operational Query T5: Payment Reconciliation & Participant Status ---")
    q5 = """
    SELECT 
        r.Registration_ID,
        part.Participant_Name,
        part.College,
        e.Event_Name,
        pay.Amount,
        pay.Payment_Mode,
        pay.Payment_Status
    FROM REGISTRATIONS r
    JOIN PARTICIPANTS part ON r.Participant_ID = part.Participant_ID
    JOIN EVENTS e ON r.Event_ID = e.Event_ID
    JOIN PAYMENTS pay ON r.Registration_ID = pay.Registration_ID;
    """
    cursor.execute(q5)
    rows5 = cursor.fetchall()
    print(f"{'RegID':<6} | {'Participant':<16} | {'College':<12} | {'Event':<26} | {'Amount':<7} | {'Mode':<12} | {'Status':<6}")
    print("-" * 95)
    for r in rows5:
        print(f"{r[0]:<6} | {r[1]:<16} | {r[2]:<12} | {r[3]:<26} | ${r[4]:<6.2f} | {r[5]:<12} | {r[6]:<6}")

    print("\n--- 📜 Operational Query T6: Issued Certificates & Awardee List ---")
    q6 = """
    SELECT 
        c.Certificate_ID,
        part.Participant_Name,
        part.College,
        e.Event_Name,
        c.Certificate_Type,
        c.Issue_Date
    FROM CERTIFICATES c
    JOIN PARTICIPANTS part ON c.Participant_ID = part.Participant_ID
    JOIN EVENTS e ON c.Event_ID = e.Event_ID;
    """
    cursor.execute(q6)
    rows6 = cursor.fetchall()
    print(f"{'CertID':<7} | {'Participant':<16} | {'College':<12} | {'Event':<26} | {'Type':<14} | {'Issue Date':<10}")
    print("-" * 95)
    for r in rows6:
        print(f"{r[0]:<7} | {r[1]:<16} | {r[2]:<12} | {r[3]:<26} | {r[4]:<14} | {r[5]:<10}")

    print("\n[COMPLETE] All TAE-1 DBMS database operational tests executed successfully.")
    conn.close()

if __name__ == "__main__":
    run_tae1_demo()
