# 📐 OmniEvent: Enhanced Conceptual Schema (ER / EER Diagram)

This document contains the complete **Enhanced Entity-Relationship (EER)** model for the OmniEvent enterprise database system, mapping physical venue management, speaker schedules, multi-tier ticketing, promo campaigns, payments, refunds, sponsorship agreements, and attendee reviews.

---

## 📊 Complete Mermaid EER Diagram

```mermaid
erDiagram
    ORGANIZER ||--o{ EVENT : organizes
    VENUE ||--|{ HALL : contains
    EVENT ||--o{ HALL_RESERVATION : reserves
    HALL ||--o{ HALL_RESERVATION : allocated_to
    EVENT ||--|{ TICKET_TIER : defines
    EVENT ||--o{ SESSION : hosts
    HALL ||--o{ SESSION : houses
    SESSION ||--|{ SESSION_SPEAKER : assigns
    SPEAKER ||--|{ SESSION_SPEAKER : participates_as
    
    USER ||--o{ BOOKING : places
    EVENT ||--o{ BOOKING : receives
    BOOKING ||--|{ TICKET_INSTANCE : generates
    TICKET_TIER ||--o{ TICKET_INSTANCE : classifies
    
    BOOKING ||--|| PAYMENT_TRANSACTION : settles
    PAYMENT_TRANSACTION ||--o{ REFUND_TRANSACTION : reverses
    
    EVENT ||--o{ PROMO_CODE : offers
    BOOKING ||--o{ BOOKING_DISCOUNT : applies
    PROMO_CODE ||--o{ BOOKING_DISCOUNT : used_in
    
    EVENT ||--o{ SPONSORSHIP : receives
    SPONSOR ||--o{ SPONSORSHIP : funds
    
    EVENT ||--o{ VENDOR_CONTRACT : engages
    VENDOR ||--o{ VENDOR_CONTRACT : provides_service
    
    EVENT ||--o{ EVENT_REVIEW : rated_by
    USER ||--o{ EVENT_REVIEW : writes

    ORGANIZER {
        int organizer_id PK
        string org_name
        string email UK
        string phone
        string tax_id UK
        timestamp created_at
    }

    VENUE {
        int venue_id PK
        string venue_name
        string street_address
        string city
        string state
        string postal_code
        int total_capacity
    }

    HALL {
        int hall_id PK
        int venue_id FK
        string hall_name
        int hall_capacity
        string floor_level
    }

    EVENT {
        int event_id PK
        int organizer_id FK
        string title
        string description
        string event_type
        date start_date
        date end_date
        string status
    }

    HALL_RESERVATION {
        int reservation_id PK
        int event_id FK
        int hall_id FK
        timestamp reserved_start
        timestamp reserved_end
        string setup_notes
    }

    SESSION {
        int session_id PK
        int event_id FK
        int hall_id FK
        string title
        string session_track
        timestamp start_time
        timestamp end_time
        int max_attendees
    }

    SPEAKER {
        int speaker_id PK
        string first_name
        string last_name
        string email UK
        string phone
        string organization
        string job_title
        string bio
        string linkedin_url
    }

    SESSION_SPEAKER {
        int session_id PK, FK
        int speaker_id PK, FK
        string role_type
    }

    TICKET_TIER {
        int tier_id PK
        int event_id FK
        string tier_name
        decimal price
        int total_allocated
        timestamp sales_start
        timestamp sales_end
    }

    USER {
        int user_id PK
        string first_name
        string last_name
        string email UK
        string phone
        timestamp registered_at
    }

    BOOKING {
        int booking_id PK
        int user_id FK
        int event_id FK
        timestamp booking_date
        decimal total_amount
        string booking_status
    }

    TICKET_INSTANCE {
        int ticket_id PK
        int booking_id FK
        int tier_id FK
        string attendee_name
        string attendee_email
        string qr_barcode_hash UK
        string check_in_status
        timestamp check_in_time
    }

    PAYMENT_TRANSACTION {
        int payment_id PK
        int booking_id FK, UK
        string gateway_ref UK
        string payment_method
        decimal amount_paid
        string status
        timestamp payment_time
    }

    REFUND_TRANSACTION {
        int refund_id PK
        int payment_id FK
        string refund_gateway_ref UK
        decimal refund_amount
        string reason
        string status
        timestamp processed_at
    }

    PROMO_CODE {
        int promo_id PK
        int event_id FK
        string code UK
        string discount_type
        decimal discount_value
        int max_redemptions
        int times_redeemed
        timestamp valid_from
        timestamp valid_until
    }

    BOOKING_DISCOUNT {
        int booking_discount_id PK
        int booking_id FK
        int promo_id FK
        decimal discount_applied
        timestamp applied_at
    }

    SPONSOR {
        int sponsor_id PK
        string company_name
        string website
        string contact_person
        string contact_email
        string contact_phone
    }

    SPONSORSHIP {
        int sponsorship_id PK
        int event_id FK
        int sponsor_id FK
        string tier_level
        decimal contribution_amount
        string booth_space_assigned
        date contract_signed_date
        string payment_status
    }

    VENDOR {
        int vendor_id PK
        string vendor_name
        string service_category
        string contact_person
        string contact_email
        string contact_phone
        string tax_identifier UK
    }

    VENDOR_CONTRACT {
        int contract_id PK
        int event_id FK
        int vendor_id FK
        decimal contract_amount
        string deliverables
        date contract_start_date
        date contract_end_date
        string payment_status
    }

    EVENT_REVIEW {
        int review_id PK
        int event_id FK
        int user_id FK
        int rating
        string feedback_text
        timestamp submitted_at
    }
```

---

## 🔑 Key Multiplicities and Business Constraints

1. **Venue Physical Topology:** $1 : N$ (`VENUE` $\rightarrow$ `HALL`). When a venue is deleted, all its halls cascade delete.
2. **Session Speaker Allocation:** $M : N$ resolved through the associative entity `SESSION_SPEAKER` (`(session_id, speaker_id)` composite primary key).
3. **Multi-Tier Ticketing:** $1 : N$ (`EVENT` $\rightarrow$ `TICKET_TIER`) and $1 : N$ (`BOOKING` $\rightarrow$ `TICKET_INSTANCE`).
4. **Ledger Consistency:** $1 : 1$ (`BOOKING` $\leftrightarrow$ `PAYMENT_TRANSACTION`), with $1 : N$ linked `REFUND_TRANSACTION` records.
5. **Auditing & Spam Prevention:** Unique constraint `(event_id, user_id)` on `EVENT_REVIEW` guarantees each user can submit at most one verified review per attended event.
