# 🎓 G H RAISONI COLLEGE OF ENGINEERING AND MANAGEMENT, PUNE
### (An Autonomous Institute Affiliated to Savitribai Phule Pune University)
### Department of Data Science | Academic Year 2026–2027

---

# 🎟️ DBMS TAE-1: EVENT MANAGEMENT DATABASE SYSTEM

[![SQL Engine](https://img.shields.io/badge/RDBMS-MS%20SQL%20Server%20%7C%20PostgreSQL%20%7C%20MySQL-0078D4?style=for-the-badge&logo=microsoftsqlserver&logoColor=white)](https://www.microsoft.com/en-us/sql-server)
[![Normalization](https://img.shields.io/badge/Normalization-1NF%20%E2%86%92%202NF%20%E2%86%92%203NF%20%E2%86%92%20BCNF-success?style=for-the-badge)](https://en.wikipedia.org/wiki/Database_normalization)
[![Course](https://img.shields.io/badge/Course-Database%20Management%20Systems-orange?style=for-the-badge)](https://en.wikipedia.org/wiki/Database)

---

## 👨‍🎓 1. Student & Submission Details

| Parameter | Details |
|:---|:---|
| **Student Name** | **Prasenjit Bakkawar** |
| **Registration Number (PRN)** | **24ACDS1121069** |
| **Section** | **A3** |
| **Branch / Class** | **TY - Data Science (TY - DS)** |
| **Department** | **Department of Data Science** |
| **Institute** | **G H Raisoni College of Engineering and Management, Pune** |
| **Evaluation Milestone** | **TAE-1 (Teacher Assessment Examination 1)** |
| **Subject** | **Database Management Systems (DBMS)** |
| **Faculty Name** | **Mr. Chinmay Mukim Sir** |

---

## 📌 2. Database System Title
**Event Management Relational Database System**

---

## 🎯 3. Problem Statement & System Requirements

### 3.1 Introduction
The **Event Management Database System** is a relational database application designed to efficiently manage the planning, organization, and execution of various events. It provides a centralized platform for storing and managing information related to events, participants, organizers, venues, registrations, payments, and certificates. The system ensures that all event-related data is maintained in a structured manner, reducing redundancy and improving data consistency.

The primary objective of this database system is to simplify event management operations by enabling efficient data storage, retrieval, and maintenance. It allows administrators to create and manage events, register participants, assign venues, process payments, monitor attendance, and generate participation certificates.

### 3.2 Problem Statement
Traditional event management methods often rely on spreadsheets or manual record-keeping, which can result in data redundancy, inconsistent records, and scheduling conflicts.

The system stores and manages information about events, participants, organizers, venues, registrations, payments, and certificates while ensuring data integrity and minimizing redundancy. It enables administrators to create and update event details, manage participant registrations, allocate venues, process payments, track attendance, and generate participation certificates.

---

### 3.3 Business Domain & Constraints

#### Enterprise Entities:
1. **Participants**
2. **Events**
3. **Organizers**
4. **Venues**
5. **Registrations**
6. **Payments**
7. **Certificates**

#### Constraints:
* Every participant has a unique `ParticipantID`.
* Every event has a unique `EventID`.
* Every organizer has a unique `OrganizerID`.
* Every venue has a unique `VenueID`.
* One participant can register for multiple events.
* One event can have multiple participants.
* Each registration belongs to one participant and one event.

### 3.4 Operational Transactions
* Add new events
* Update event details
* Register participants
* Assign organizers to events
* Process registration payments
* Record participant attendance & issue certificates

---

## 📚 4. Literature & System Reference

* **Reference 1:** *Event Management System Using Web Technology*
* **Reference 2:** *Database System Concepts* (Silberschatz, Korth, Sudarshan)
* **Reference 3:** *Fundamentals of Database Systems (7th Edition)* (Elmasri & Navathe) — Comprehensive reference for ER modeling, relational schema design, normalization (1NF to BCNF).

---

## 📐 5. Conceptual Schema (ER Diagram)

```mermaid
erDiagram
    ORGANIZERS ||--o{ EVENTS : organizes
    VENUES ||--o{ EVENTS : hosts
    EVENTS ||--|{ REGISTRATIONS : has
    PARTICIPANTS ||--|{ REGISTRATIONS : registers_for
    REGISTRATIONS ||--|| PAYMENTS : paid_by
    PARTICIPANTS ||--o{ CERTIFICATES : receives
    EVENTS ||--o{ CERTIFICATES : awards

    ORGANIZERS {
        int Organizer_ID PK
        string Organizer_Name
        string Email UK
        string Phone
    }

    VENUES {
        int Venue_ID PK
        string Venue_Name
        string Location
        int Capacity
    }

    EVENTS {
        int Event_ID PK
        int Organizer_ID FK
        int Venue_ID FK
        string Event_Name
        date Event_Date
        string Category
        decimal Registration_Fee
    }

    PARTICIPANTS {
        int Participant_ID PK
        string Participant_Name
        string Email UK
        string Phone
        string College
        string Department
    }

    REGISTRATIONS {
        int Registration_ID PK
        int Participant_ID FK
        int Event_ID FK
        date Registration_Date
        string Status
    }

    PAYMENTS {
        int Payment_ID PK
        int Registration_ID FK, UK
        decimal Amount
        string Payment_Mode
        date Payment_Date
        string Payment_Status
    }

    CERTIFICATES {
        int Certificate_ID PK
        int Participant_ID FK
        int Event_ID FK
        string Certificate_Type
        date Issue_Date
    }
```

---

## 🔄 6. Normalization (UNF $\rightarrow$ 1NF $\rightarrow$ 2NF $\rightarrow$ 3NF $\rightarrow$ BCNF)

### 6.1 Unnormalized Form (UNF)
Initially, all event information is stored in a single flat table with repeating groups:

| RegistrationID | ParticipantName | Phone | EventName | Organizer | Venue | Payment | Certificate |
|---|---|---|---|---|---|---|---|
| **R001** | Aarav Sharma | 9876543210 | Hackathon | Rahul Mehta | Auditorium | Paid | Yes |
| **R001** | Aarav Sharma | 9876543210 | AI Workshop | Rahul Mehta | Lab 1 | Paid | No |

**Problems:**
- Repeated participant information.
- Duplicate event details.
- Data redundancy and update anomalies.

---

### 6.2 First Normal Form (1NF)
Remove repeating groups and ensure each attribute contains only atomic values.

#### Registration Table (1NF):
| Registration_ID (PK) | Participant_ID | Event_ID | Registration_Date | Status |
|---|---|---|---|---|
| **R001** | P001 | E001 | 2026-10-09 | Registered |
| **R002** | P001 | E002 | 2026-10-15 | Registered |

---

### 6.3 Second Normal Form (2NF)
Remove partial functional dependencies so each non-key attribute depends on the entire primary key.

1. **`PARTICIPANTS`:** (`Participant_ID`, `Participant_Name`, `Email`, `Phone`, `College`, `Department`)
2. **`EVENTS`:** (`Event_ID`, `Event_Name`, `Event_Date`, `Category`, `Venue_ID`, `Organizer_ID`, `Registration_Fee`)
3. **`REGISTRATIONS`:** (`Registration_ID`, `Participant_ID`, `Event_ID`, `Registration_Date`, `Status`)

---

### 6.4 Third Normal Form (3NF)
Remove transitive dependencies ($X \rightarrow Y \rightarrow Z$) so non-key attributes depend only on primary keys.

1. **`ORGANIZERS`:** (`Organizer_ID`, `Organizer_Name`, `Email`, `Phone`)
2. **`VENUES`:** (`Venue_ID`, `Venue_Name`, `Location`, `Capacity`)
3. **`PAYMENTS`:** (`Payment_ID`, `Registration_ID`, `Amount`, `Payment_Mode`, `Payment_Status`, `Payment_Date`)
4. **`CERTIFICATES`:** (`Certificate_ID`, `Participant_ID`, `Event_ID`, `Certificate_Type`, `Issue_Date`)

---

### 6.5 Boyce–Codd Normal Form (BCNF)
The database satisfies BCNF because:
- Every table has a single candidate key.
- Every determinant is a candidate key.
- No non-key attribute determines another attribute.
- All functional dependencies have candidate keys on the left side.

---

## 💻 7. Target RDBMS Software

* **Database Engine:** **Microsoft SQL Server / PostgreSQL / MySQL**
* **Summary:**
  Microsoft SQL Server / PostgreSQL is selected as the database engine because it efficiently manages relational data and ensures data integrity using Primary Keys and Foreign Keys. It is well-suited for handling the Participants, Events, Registrations, Payments, and Certificates tables, allowing fast data retrieval, secure storage, and reliable transaction processing. SQL Server also supports SQL queries, joins, constraints, and indexing, making it an ideal choice for developing the **Event Management Database System**.
