-- ============================================================================
-- G H RAISONI COLLEGE OF ENGINEERING AND MANAGEMENT, PUNE
-- DBMS TAE-1: EVENT MANAGEMENT DATABASE SYSTEM
-- Operational SQL Transactions & Analytical Queries (T1 to T6)
-- ============================================================================

-- T1: Add a New Event (Insert Operation)
INSERT INTO EVENTS (Event_ID, Event_Name, Event_Date, Category, Registration_Fee, Venue_ID, Organizer_ID)
VALUES (304, 'Data Science HackFest 2026', '2026-11-25', 'Hackathon', 300.00, 201, 101);

-- T2: Update Event Details & Reschedule
UPDATE EVENTS 
SET Event_Date = '2026-11-28', Registration_Fee = 280.00 
WHERE Event_ID = 304;

-- T3: Register a Participant for an Event
INSERT INTO REGISTRATIONS (Registration_ID, Participant_ID, Event_ID, Registration_Date, Status)
VALUES (506, 404, 301, CURRENT_DATE, 'Registered');

-- T4: Event-wise Participant Registration Report (JOIN query)
SELECT 
    e.Event_ID,
    e.Event_Name,
    e.Event_Date,
    v.Venue_Name,
    o.Organizer_Name,
    COUNT(r.Registration_ID) AS Total_Registered_Participants,
    COALESCE(SUM(p.Amount), 0.00) AS Total_Fee_Collected
FROM EVENTS e
JOIN VENUES v ON e.Venue_ID = v.Venue_ID
JOIN ORGANIZERS o ON e.Organizer_ID = o.Organizer_ID
LEFT JOIN REGISTRATIONS r ON e.Event_ID = r.Event_ID
LEFT JOIN PAYMENTS p ON r.Registration_ID = p.Registration_ID AND p.Payment_Status = 'Paid'
GROUP BY e.Event_ID, e.Event_Name, e.Event_Date, v.Venue_Name, o.Organizer_Name;

-- T5: Payment Reconciliation & Participant Status
SELECT 
    r.Registration_ID,
    part.Participant_Name,
    part.College,
    e.Event_Name,
    pay.Amount,
    pay.Payment_Mode,
    pay.Payment_Status,
    pay.Payment_Date
FROM REGISTRATIONS r
JOIN PARTICIPANTS part ON r.Participant_ID = part.Participant_ID
JOIN EVENTS e ON r.Event_ID = e.Event_ID
JOIN PAYMENTS pay ON r.Registration_ID = pay.Registration_ID;

-- T6: Certificate Verification & Awardee List
SELECT 
    c.Certificate_ID,
    part.Participant_Name,
    part.Email,
    part.College,
    e.Event_Name,
    c.Certificate_Type,
    c.Issue_Date
FROM CERTIFICATES c
JOIN PARTICIPANTS part ON c.Participant_ID = part.Participant_ID
JOIN EVENTS e ON c.Event_ID = e.Event_ID
ORDER BY c.Issue_Date DESC;
