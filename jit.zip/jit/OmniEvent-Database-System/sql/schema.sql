-- ============================================================================
-- G H RAISONI COLLEGE OF ENGINEERING AND MANAGEMENT, PUNE
-- Department of Data Science | DBMS TAE-1
-- Title: EVENT MANAGEMENT DATABASE SYSTEM
-- Student: Prasenjit Bakkawar (PRN: 24ACDS1121069) | Section: A3 | TY-DS
-- Faculty: Mr. Chinmay Mukim Sir
-- Target Database: Microsoft SQL Server / PostgreSQL 15+ / MySQL 8.0+
-- Standard: Fully Normalized (1NF -> 2NF -> 3NF -> BCNF)
-- ============================================================================

-- Clean existing tables in reverse dependency order
DROP TABLE IF EXISTS CERTIFICATES CASCADE;
DROP TABLE IF EXISTS PAYMENTS CASCADE;
DROP TABLE IF EXISTS REGISTRATIONS CASCADE;
DROP TABLE IF EXISTS PARTICIPANTS CASCADE;
DROP TABLE IF EXISTS EVENTS CASCADE;
DROP TABLE IF EXISTS VENUES CASCADE;
DROP TABLE IF EXISTS ORGANIZERS CASCADE;

-- 1. ORGANIZERS TABLE
CREATE TABLE ORGANIZERS (
    Organizer_ID INT PRIMARY KEY,
    Organizer_Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    Phone VARCHAR(20) NOT NULL
);

-- 2. VENUES TABLE
CREATE TABLE VENUES (
    Venue_ID INT PRIMARY KEY,
    Venue_Name VARCHAR(100) NOT NULL,
    Location VARCHAR(150) NOT NULL,
    Capacity INT NOT NULL CHECK (Capacity > 0)
);

-- 3. EVENTS TABLE
CREATE TABLE EVENTS (
    Event_ID INT PRIMARY KEY,
    Event_Name VARCHAR(150) NOT NULL,
    Event_Date DATE NOT NULL,
    Category VARCHAR(50) NOT NULL, -- 'Technical', 'Hackathon', 'Workshop', 'Cultural'
    Registration_Fee DECIMAL(10, 2) NOT NULL CHECK (Registration_Fee >= 0.00),
    Venue_ID INT NOT NULL,
    Organizer_ID INT NOT NULL,
    FOREIGN KEY (Venue_ID) REFERENCES VENUES(Venue_ID) ON DELETE RESTRICT,
    FOREIGN KEY (Organizer_ID) REFERENCES ORGANIZERS(Organizer_ID) ON DELETE RESTRICT
);

-- 4. PARTICIPANTS TABLE
CREATE TABLE PARTICIPANTS (
    Participant_ID INT PRIMARY KEY,
    Participant_Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    Phone VARCHAR(20) NOT NULL,
    College VARCHAR(150) NOT NULL,
    Department VARCHAR(100) NOT NULL
);

-- 5. REGISTRATIONS TABLE (M:N Associative Entity connecting Participants & Events)
CREATE TABLE REGISTRATIONS (
    Registration_ID INT PRIMARY KEY,
    Participant_ID INT NOT NULL,
    Event_ID INT NOT NULL,
    Registration_Date DATE NOT NULL,
    Status VARCHAR(30) DEFAULT 'Registered' CHECK (Status IN ('Registered', 'Attended', 'Cancelled')),
    FOREIGN KEY (Participant_ID) REFERENCES PARTICIPANTS(Participant_ID) ON DELETE CASCADE,
    FOREIGN KEY (Event_ID) REFERENCES EVENTS(Event_ID) ON DELETE CASCADE,
    UNIQUE (Participant_ID, Event_ID) -- Enforce 1 registration per participant per event
);

-- 6. PAYMENTS TABLE (1:1 with Registration)
CREATE TABLE PAYMENTS (
    Payment_ID INT PRIMARY KEY,
    Registration_ID INT UNIQUE NOT NULL,
    Amount DECIMAL(10, 2) NOT NULL CHECK (Amount >= 0.00),
    Payment_Mode VARCHAR(50) NOT NULL CHECK (Payment_Mode IN ('UPI', 'Credit Card', 'Debit Card', 'Net Banking', 'Cash')),
    Payment_Date DATE NOT NULL,
    Payment_Status VARCHAR(30) DEFAULT 'Paid' CHECK (Payment_Status IN ('Paid', 'Pending', 'Failed', 'Refunded')),
    FOREIGN KEY (Registration_ID) REFERENCES REGISTRATIONS(Registration_ID) ON DELETE CASCADE
);

-- 7. CERTIFICATES TABLE
CREATE TABLE CERTIFICATES (
    Certificate_ID INT PRIMARY KEY,
    Participant_ID INT NOT NULL,
    Event_ID INT NOT NULL,
    Certificate_Type VARCHAR(50) NOT NULL CHECK (Certificate_Type IN ('Participation', 'Merit', 'Winner', 'Runner-up', 'Organizer')),
    Issue_Date DATE NOT NULL,
    FOREIGN KEY (Participant_ID) REFERENCES PARTICIPANTS(Participant_ID) ON DELETE CASCADE,
    FOREIGN KEY (Event_ID) REFERENCES EVENTS(Event_ID) ON DELETE CASCADE
);

-- Indexes for Fast Query Optimization
CREATE INDEX idx_reg_participant ON REGISTRATIONS(Participant_ID);
CREATE INDEX idx_reg_event ON REGISTRATIONS(Event_ID);
CREATE INDEX idx_payments_reg ON PAYMENTS(Registration_ID);
CREATE INDEX idx_cert_participant_event ON CERTIFICATES(Participant_ID, Event_ID);
