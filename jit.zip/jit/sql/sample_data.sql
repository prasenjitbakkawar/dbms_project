-- ============================================================================
-- G H RAISONI COLLEGE OF ENGINEERING AND MANAGEMENT, PUNE
-- DBMS TAE-1: EVENT MANAGEMENT DATABASE SYSTEM
-- Sample Seed Data
-- ============================================================================

INSERT INTO ORGANIZERS (Organizer_ID, Organizer_Name, Email, Phone) VALUES
(101, 'Prof. Rahul Mehta', 'rahul.mehta@ghrcem.edu.in', '9876543210'),
(102, 'Dr. Sneha Kulkarni', 'sneha.kulkarni@ghrcem.edu.in', '9822012345'),
(103, 'Prof. Amit Verma', 'amit.verma@ghrcem.edu.in', '9765432109');

INSERT INTO VENUES (Venue_ID, Venue_Name, Location, Capacity) VALUES
(201, 'Central Auditorium', 'Main Building, Ground Floor', 500),
(202, 'Data Science Lab 1', 'Department of Data Science, 3rd Floor', 80),
(203, 'Seminar Hall A', 'Mechanical Block, 2nd Floor', 150);

INSERT INTO EVENTS (Event_ID, Event_Name, Event_Date, Category, Registration_Fee, Venue_ID, Organizer_ID) VALUES
(301, 'National Hackathon 2026', '2026-10-15', 'Hackathon', 250.00, 201, 101),
(302, 'Hands-on AI & ML Workshop', '2026-10-20', 'Workshop', 150.00, 202, 102),
(303, 'Web3 & Cloud Symposium', '2026-11-05', 'Technical', 100.00, 203, 103);

INSERT INTO PARTICIPANTS (Participant_ID, Participant_Name, Email, Phone, College, Department) VALUES
(401, 'Aarav Sharma', 'aarav.sharma@gmail.com', '9876543210', 'GHRCEM Pune', 'Data Science'),
(402, 'Priya Patil', 'priya.patil@gmail.com', '9823456781', 'GHRCEM Pune', 'Computer Engineering'),
(403, 'Rohan Deshmukh', 'rohan.d@gmail.com', '9890123456', 'COEP Pune', 'Information Technology'),
(404, 'Ananya Joshi', 'ananya.j@gmail.com', '9765123489', 'PICT Pune', 'Data Science');

INSERT INTO REGISTRATIONS (Registration_ID, Participant_ID, Event_ID, Registration_Date, Status) VALUES
(501, 401, 301, '2026-10-01', 'Attended'),
(502, 401, 302, '2026-10-02', 'Registered'),
(503, 402, 301, '2026-10-03', 'Attended'),
(504, 403, 302, '2026-10-04', 'Attended'),
(505, 404, 303, '2026-10-05', 'Registered');

INSERT INTO PAYMENTS (Payment_ID, Registration_ID, Amount, Payment_Mode, Payment_Date, Payment_Status) VALUES
(601, 501, 250.00, 'UPI', '2026-10-01', 'Paid'),
(602, 502, 150.00, 'UPI', '2026-10-02', 'Paid'),
(603, 503, 250.00, 'Credit Card', '2026-10-03', 'Paid'),
(604, 504, 150.00, 'Net Banking', '2026-10-04', 'Paid'),
(605, 505, 100.00, 'UPI', '2026-10-05', 'Paid');

INSERT INTO CERTIFICATES (Certificate_ID, Participant_ID, Event_ID, Certificate_Type, Issue_Date) VALUES
(701, 401, 301, 'Winner', '2026-10-16'),
(702, 402, 301, 'Runner-up', '2026-10-16'),
(703, 403, 302, 'Participation', '2026-10-21');
